<footer>
    <div class="content">
         <article>
           <ul>
             <li>
               <h2>Punto Coaching</h2>
               <p>Trabajamos por la profesionalización del Coaching <br> Ontológico a través de nuestro diplomado con <br>
              certificación internacional por la ICMF (International <br>  
              Coaching and Mentoring Federation).</p>
            </li>
             <li>
               <h2>Ubicación</h2>
               <p>Lago Neuchatel #45 Col. Ampliación Granada. <br>
                 Ciudad de México.</p>
            </li>
             <li>
               <h2>Síguenos</h2>
               <p>
                 <a target="_blank"href="https://www.facebook.com/Punto-Coaching-856483147810888/?fref=ts">Facebook</a>
               </p>
            </li>
           </ul>
         </article>
       </div>
       <div class="content">
         <article>
           <ul> 
            <!--** <li><a href="#"> Incio </a></li>
             <li><a href="#"> Mapa de sitio </a></li>
             <li><a href="#"> Aviso de privacidad</a></li>
             <li><a href="#"> Contacto </a></li>--> 
           </ul>
           <ul>
             <li> <img src="<?php bloginfo('template_url')?>/assets/img/logoGrey.png" alt=""></li>
             <li>Todos los derechos reservados. <br>
                    Punto Coaching 2016</li>
           </ul>
         </article>
       </div>
     </div>
</footer>
</body>
<script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
<script src="<?php bloginfo('template_url')?>/assets/js/materialize.js"></script>
<script src="<?php bloginfo('template_url')?>/assets/js/main.js"></script> 

</html>