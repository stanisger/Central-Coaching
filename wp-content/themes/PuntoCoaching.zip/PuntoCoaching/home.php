<?php  
/*
Template Name: Home
*/
 ?>

<?php get_header(); ?>

<?php include (TEMPLATEPATH. '/eyecatcher.php'); ?>
<?php include (TEMPLATEPATH. '/firstSection.php'); ?>
<?php include (TEMPLATEPATH. '/secondSection.php'); ?>
<?php include (TEMPLATEPATH. '/thirdSection.php'); ?>
<section id="fourSection">
     <div class="content">
       <article>
         <h3>Testimoniales</h3>
         <p>Personas y empresas que han <br>
            conseguido sus metas.</p>
         <!--  <p class="btnContent">
           <button class="btnColor btn-1 btn-1d">CONOCE MÁS</button>
          </p> -->     
       </article>
       <article>
        <div class="contentElements">
            <div class="element">
                 <a href="#">
                  <i class="flaticon-commenting" aria-hidden="true"></i>
                </a>
                <img src="<?php bloginfo('template_url')?>/assets/img/tests1.jpg" alt="">
                <div class="text">
                  <h3>Mónica Areuza Alarcón García</h3>
                  <h4>Docente y Coach Ontológico</h4>  
                </div>
                <p>
                  “Mi experiencia con Jaime como coach facilitador, ha sido una de las mejores en mi vida, ya que su sentido humano y sobre todo lo oportuno de su ser y estar ”
                </p>
            </div>  
         </div>
         <div class="contentElements">
            <div class="element">
                 <a href="#">
                  <i class="flaticon-commenting" aria-hidden="true"></i>
                </a>
                <img src="<?php bloginfo('template_url')?>/assets/img/tests2.jpg" alt="">                <div class="text">
                  <h3>Fernanda López Ruelas</h3>
                  <h4>Terapeuta </h4>  
                </div>
                <p>
                  "Mi experiencia  fue muy buena. Fui a ver si realmente me interesaba el coaching ontológico, y la forma en que Jaime dio el curso y la claridad”
                </p>
            </div>  
         </div>
    <!--     <div class="contentElements">
            <div class="element">
                <a href="#">
                  <i class="flaticon-commenting" aria-hidden="true"></i>
                </a>  
                <img src="assets/img/thumbnailPerfil2.png" alt="">
                <div class="text">
                  <h3>Claudia Montiel</h3>
                  <h4>Arquitecto</h4>  
                </div>
                <p>
                  “Phasellus viverra nulla ut metus varius laoreet. Quisque rutrum.”
                </p>
            </div>  
         </div> -->
         <!--  <div class="contentElements">
            <div class="element">
                <a href="#">
                  <i class="flaticon-commenting" aria-hidden="true"></i>
                </a>  
                <img src="assets/img/thumbnailPerfil2.png" alt="">
                <div class="text">
                  <h3>Claudia Montiel</h3>
                  <h4>Arquitecto</h4>  
                </div>
                <p>
                  “Phasellus viverra nulla ut metus varius laoreet. Quisque rutrum.”
                </p>
            </div>  
         </div> -->
       </article>
      <!--  <p class="btnContent">
         <button class="btnColor btn-1 btn-1d">VER MÁS</button>
        </p>  -->
     </div>
     <!-- <div class="controls2">
       <a class="btn-carousel" id="scrollUp" href="#">
        <i class="flaticon-arrows-1"></i>
      </a>
      <a class="btn-carousel" id="scrollDown" href="#">
        <i class="flaticon-arrows-3"></i>
      </a>
    </div>  -->
   </section>

<?php get_footer(); ?>
	