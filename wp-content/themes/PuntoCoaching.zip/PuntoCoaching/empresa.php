<?php  
/*
Template Name: Empresa
*/
 ?>

<?php get_header(); ?>


<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>


<!--**HEAD**-->  
<section id="eyecatcherInEmpresa">
  <?php if( have_rows('head') ): ?>
  <?php while( have_rows('head') ): the_row();
  $title = get_sub_field('title');
  $discriptionHead = get_sub_field('discriptionHead');
  $image = get_sub_field('image');
  ?>
    <div class="content">
      <div class="text">
        <h2>Soy Empresa</h2>
        <h1><?php echo $title; ?></h1>
        <p><?php echo $discriptionHead; ?></p>
      </div>  
      <div class="degrade"></div>
      <img src="<?php echo $image; ?>" alt="">
    </div>
  <?php endwhile; else: ?>
  <h1>no hay post</h1>
  <?php endif; ?>   
</section>
<!--**HEAD**-->


<section id="InfoEmpresa">
    <div class="content">
      <?php if( have_rows('talleres') ): ?>
      <?php while( have_rows('talleres') ): the_row();

        $name = get_sub_field('name');
        $text = get_sub_field('text');
        $icon = get_sub_field('icon');
     ?>
      <article>
        <div class="content">
          <i class="<?php echo $icon; ?>"></i>
          <h4><?php echo $name; ?></h4>
          <p><?php echo $text; ?></p>
        </div>  
      </article>

    <!--   <span class="line"></span> -->

    <?php endwhile; else: ?>
    <h1>no hay post</h1>
    <?php endif; ?> 


    </div>
</section>


<section id="resumeEmpresa">
     <div class="content">
      <article> 
        <h3><?php the_field('resume-subtitle'); ?></h3>
        <h2><?php the_field('resume-title'); ?></h2>
      </article>
      
      <article>
       
       <div class="contentAside">
        <?php if( have_rows('curses') ): ?>
        <?php while( have_rows('curses') ): the_row();

            $title = get_sub_field('title');
            $text = get_sub_field('text');
            $img2 = get_sub_field('img2');
        ?>
        
        <aside>

              <img src="<?php echo $img2; ?>" alt="#" />
 
            <h3><?php echo $title; ?></h3>
            <div class="text">
              <?php echo $text; ?>
            </div>
               
        </aside>

        <?php endwhile; else: ?>
        <h1>no hay post</h1>
        <?php endif; ?> 

       </div> 
         <p class="btnContent">
               <a href="<?php the_field('link'); ?>"><button class="btnColor btn-1 btn-1d">INSCRÍBETE</button></a>
        </p> 
      </article>
     </div> 
</section>



<?php endwhile; else: ?>
<h1>no hay post</h1>
<?php endif; ?> 
<section id="fourSection">
     <div class="content">
       <article>
         <h3>Testimoniales</h3>
         <p>Personas y empresas que han <br>
            conseguido sus metas.</p>
         <!--  <p class="btnContent">
           <button class="btnColor btn-1 btn-1d">CONOCE MÁS</button>
          </p> -->     
       </article>
       <article>
        <div class="contentElements">
            <div class="element">
                 <a href="#">
                  <i class="flaticon-commenting" aria-hidden="true"></i>
                </a>
                <img src="<?php bloginfo('template_url')?>/assets/img/tests1.jpg" alt="">
                <div class="text">
                  <h3>Mónica Areuza Alarcón García</h3>
                  <h4>Docente y Coach Ontológico</h4>  
                </div>
                <p>
                  “Mi experiencia con Jaime como coach facilitador, ha sido una de las mejores en mi vida, ya que su sentido humano y sobre todo lo oportuno de su ser y estar ”
                </p>
            </div>  
         </div>
         <div class="contentElements">
            <div class="element">
                 <a href="#">
                  <i class="flaticon-commenting" aria-hidden="true"></i>
                </a>
                <img src="<?php bloginfo('template_url')?>/assets/img/tests2.jpg" alt="">                <div class="text">
                  <h3>Fernanda López Ruelas</h3>
                  <h4>Terapeuta </h4>  
                </div>
                <p>
                  "Mi experiencia  fue muy buena. Fui a ver si realmente me interesaba el coaching ontológico, y la forma en que Jaime dio el curso y la claridad”
                </p>
            </div>  
         </div>
    <!--     <div class="contentElements">
            <div class="element">
                <a href="#">
                  <i class="flaticon-commenting" aria-hidden="true"></i>
                </a>  
                <img src="assets/img/thumbnailPerfil2.png" alt="">
                <div class="text">
                  <h3>Claudia Montiel</h3>
                  <h4>Arquitecto</h4>  
                </div>
                <p>
                  “Phasellus viverra nulla ut metus varius laoreet. Quisque rutrum.”
                </p>
            </div>  
         </div> -->
         <!--  <div class="contentElements">
            <div class="element">
                <a href="#">
                  <i class="flaticon-commenting" aria-hidden="true"></i>
                </a>  
                <img src="assets/img/thumbnailPerfil2.png" alt="">
                <div class="text">
                  <h3>Claudia Montiel</h3>
                  <h4>Arquitecto</h4>  
                </div>
                <p>
                  “Phasellus viverra nulla ut metus varius laoreet. Quisque rutrum.”
                </p>
            </div>  
         </div> -->
       </article>
      <!--  <p class="btnContent">
         <button class="btnColor btn-1 btn-1d">VER MÁS</button>
        </p>  -->
     </div>
     <!-- <div class="controls2">
       <a class="btn-carousel" id="scrollUp" href="#">
        <i class="flaticon-arrows-1"></i>
      </a>
      <a class="btn-carousel" id="scrollDown" href="#">
        <i class="flaticon-arrows-3"></i>
      </a>
    </div>  -->
   </section>


<?php get_footer(); ?>