<?php get_header(); ?>

<?php include (TEMPLATEPATH. '/eyecatcher.php'); ?>
<?php include (TEMPLATEPATH. '/firstSection.php'); ?>
<?php include (TEMPLATEPATH. '/secondSection.php'); ?>
<?php include (TEMPLATEPATH. '/thirdSection.php'); ?>
<?php include (TEMPLATEPATH. '/fourSection.php'); ?>

<?php get_footer(); ?>
	